<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Modal Periode -->
    <div id="modalperiodenull" class="modal fade">
        <div class="modal-dialog modal-confirm">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="icon-box">
                        <i class="fas fa-times fa-3x"></i>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="text-center">Messages</h2>
                    <p style="text-align: center;">Masukan Tanggal Periode Laporan</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Sukses -->
    <div id="myModal202" class="modal fade">
        <div class="modal-dialog modal-confirm">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="icon-box bg-success">
                        <i class="fas fa-check fa-3x"></i>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="text-center">Messages</h2>
                    <p style="text-align: center;">Cetak Laporan Berhasil</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Gagal -->
    <div id="myModal203" class="modal fade">
        <div class="modal-dialog modal-confirm">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="icon-box">
                        <i class="fas fa-times fa-3x"></i>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="text-center">Messages</h2>
                    <p style="text-align: center;">Pencetakan Laporan Kegiatan Maksimal 2 Bulan (60 hari) dalam sekali transkasi</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Header (Page header) -->
    <!-- <section class="content-header">

    </section> -->

    <!-- Main content -->

    <!-- /.content -->

    <!-- Main content -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Penilaian PNASN</h1>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <div class="container-fluid">
        <!-- Card Base -->
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Input Penilaian Kinerja</h3>
            </div>
            <div class="card-body">
                <!-- form biodata -->
                <!-- <div class="card card-default">
                        <div class="card-body"> -->
                <div class="row">
                    <!-- <div class="row"> -->
                    <div class="col-12">
                        <div class="card card-primary">
                            <!-- <div class="card-header">
                                    <h3 class="card-title">Form Input Penilaian</h3>
                                </div> -->

                            <!-- <form enctype="multipart/form-data" method="post" action="<?php echo base_url() ?>index.php/xxx/submit_kinerjaPegawai"> -->
                            <form>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="form-group">
                                        <h2 style="text-align: left;">Penilaian PNASN</h2>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group">
                                                    <label>Nama PNASN</label>
                                                    <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('nama'); ?></label>
                                                    <select name="nama" id="nama" class="form-control custom-select">
                                                        <option value="">- Select Nama -</option>
                                                        <?php
                                                        foreach ($dataPegawai as $data) {
                                                            echo '<option value="' . $data->emp_id . '" >' . $data->nama_depan . " " . $data->nama_belakang . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                    <span id="nama_error" class="text-danger"></span>
                                                </div>

                                                <div class="form-group">
                                                    <label>Periode Penilaian</label>
                                                    <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('periode'); ?></label>
                                                    <select name="periode" id="periode" class="form-control custom-select" id="periode">
                                                        <option value="">- Select Periode -</option>
                                                        <option value="1">Januari</option>
                                                        <option value="2">Februari</option>
                                                        <option value="3">Maret</option>
                                                        <option value="4">April</option>
                                                        <option value="5">Mai</option>
                                                        <option value="6">Juni</option>
                                                        <option value="7">Juli</option>
                                                        <option value="8">Agustus</option>
                                                        <option value="9">September</option>
                                                        <option value="10">Oktober</option>
                                                        <option value="11">November</option>
                                                        <option value="12">Desember</option>
                                                    </select>
                                                    <span id="periode_error" class="text-danger"></span>
                                                </div>

                                                <div class="form-group">
                                                    <label>Score Penilaian</label>
                                                    <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('score'); ?></label>
                                                    <select name="score" id="score" class="form-control custom-select">
                                                        <option value="">- Select Score -</option>
                                                        <option value="0">Kurang Baik</option>
                                                        <option value="1">Baik</option>
                                                        <option value="2">Sangat Baik</option>
                                                    </select>
                                                    <span id="score_error" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group">
                                                    <label>Keterangan</label>
                                                    <textarea name="pelakKegiatan" class="pelakKegiatan" id="keterangan" style="width: 100%; height: 200px;  padding: 20px;margin: 15px 0;"></textarea>
                                                    <!-- <textarea name="keterangan" class="keterangan" id="keterangan" style="height: 300px;">
                                                                Tuliskan <em>keterangan</em> <u>disini</u>                               
                                                                </textarea> -->
                                                    <span id="keterangan_error" class="text-danger"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="modal-footer">
                                        <button type="button" id="btn_simpan" class="btn btn-primary">Simpan</button>
                                        <!-- <button class="btn" id="btn_tutup" data-dismiss="modal" aria-hidden="true">Tutup</button> -->
                                        <!-- <button class="btn btn-info" id="btn_simpan">Simpan</button> -->
                                    </div>
                                    <!-- <button type="submit" class="btn btn-primary">Kirim</button>
                                        <a class="btn btn-danger" href="<?php echo base_url() ?>index.php/PenilaianKinerja/PenilaianKinerja">Kembali</a> -->
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-md-3 col-sm-12 col-lg-3">
                        <div class="form-group">
                            <select name="id_emp" class="form-control custom-select" id="id_emp">
                                <?php
                                foreach ($dataPegawai as $data) {
                                    echo '<option value="' . $data->emp_id . '" >' . $data->nama_depan . " " . $nama_belakang . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-12 col-lg-9">
                        <button class="btn btn-primary" id="btn_cari"><i class="fas fa-search"></i> Lihat Laporan bulan ini</button>
                    </div>
                    <br>
                </div>
            </div>
            <div class="card-body table-responsive">
                <table id="example3" class="table responive table-bordered table-striped">
                    <thead>
                        <tr style="text-align: center;">
                            <th style="vertical-align: middle; width: 10%;">Tanggal</th>
                            <th style="vertical-align: middle; width: 12%;">Waktu</th>
                            <th style="vertical-align: middle;">Uraian Tugas</th>
                            <th style="vertical-align: middle; width: 8%;">Jumlah Terselesaikan</th>
                        </tr>
                    </thead>
                    <tbody id="show_data">
                    </tbody>
                </table>
                <!-- </div>
                    </div> -->
            </div>
        </div><!-- /.card base -->

    </div><!-- /.container-fluid -->
</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
    <?php
    $this->load->view('admin/template/4footer');
    ?>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src=" <?php echo base_url() ?>asset/plugin/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>asset/plugin/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & plugin -->
<script src="<?php echo base_url() ?>asset/plugin/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/jszip/jszip.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src=" <?php echo base_url() ?>asset/js/adminlte.min.js"></script>
<!-- Page specific script -->
<!-- Page specific script -->
<script src="<?php echo base_url() ?>asset/plugin/summernote/summernote-bs4.min.js"></script>
<script>
    tampil_data_laporan();

    var $printStatus = "<?php
                        echo $this->session->userdata('print_stats');
                        ?>";

    $(document).ready(function() {
        if ($printStatus == '1') {
            $("#myModal203").modal();
        } else if ($printStatus == '0') {
            $("#myModal202").modal();
        }
    });

    $(document).ready(function() {
        // const d = new Date();
        // var month = d.getMonth() + 1;
        // var year = d.getFullYear();
        // var afd = year + '-0' + month + "-01";
        // var dateString = '' + year + '-' + month;
        // var a = new Date(afd);
        // // var dt = new Date();
        // // var date = dt.getMonth() + 1;
        // console.log(a);
    });

    $("#example3").DataTable({
        "responsive": true,
        "lengthChange": false,
        "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example3_wrapper .col-md-6:eq(0)');

    $(document).ready(function() {
        // var date = $('#aft_date').datepicker('getDate');
        $('#btn_cari').on('click', function() {
            const d = new Date();
            var month = d.getMonth() + 1;
            var year = d.getFullYear();
            var bef = year + '-0' + month + "-01";
            var aft = year + '-0' + month + "-31";
            var bef_date = new Date(bef);
            var aft_date = new Date(aft);
            // var bef_date = new Date($('#bef_date').val());
            // var aft_date = new Date($('#aft_date').val());
            var id_emp = $('#id_emp').val();
            // console.log(waktu);
            // console.log(bef_date);

            var error = 0;
            if ($.trim(bef_date) == 'Invalid Date') {
                ++error;
            }
            if ($.trim(aft_date) == 'Invalid Date') {
                ++error;
            }

            if (error > 0) {
                // alert('kosong');
                $('#modalperiodenull').modal('show')
                lblbef_date.style.visibility = 'visible';
                lblaft_date.style.visibility = 'visible';
            } else {
                var bef_year = bef_date.getFullYear();
                var bef_month = bef_date.getMonth() + 1;
                var bef_day = bef_date.getDate();

                var aft_year = aft_date.getFullYear();
                var aft_month = aft_date.getMonth() + 1;
                var aft_day = aft_date.getDate();
                // alert('isi');

                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('index.php/SVC_GetAjax/cari_laporan_pegawaiPimp_ajax') ?>",
                    dataType: "JSON",
                    async: false,
                    data: {
                        id_emp: id_emp,
                        tanggal: bef_day,
                        bulan: bef_month,
                        tahun: bef_year,
                        stanggal: aft_day,
                        sbulan: aft_month,
                        stahun: aft_year,
                    },
                    success: function(data) {
                        // console.log(data);
                        // window.location.href = "<?php echo base_url('index.php/PenilaianKinerja/penilaianKinerja') ?>"
                        tampil_data_laporan();
                        // $('#example3').data.reload();
                    },
                    error: function() {
                        alert('Maaf data tidak tersedia');

                    }
                });
                return false;
            }
        });
    });

    $(document).ready(function() {
        $("form").submit(function(event) {
            if ($("input").first().val() === "correct") {
                $("span").text("Validated...").show();
                return;
            }

            $("span").text("Not valid!").show().fadeOut(1000);
            event.preventDefault();
        });
    });

    function tampil_data_laporan() {
        $.ajax({
            type: 'GET',
            url: '<?php echo base_url() ?>index.php/SVC_GetAjax/daftar_laporanUser_ajax',
            async: false,
            dataType: 'json',
            success: function(data) {
                // console.log(data);
                var html = '';
                var i;
                for (i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td style="text-align: center;">' + data[i].waktu + '</td>' +
                        '<td style="text-align: center;">' + data[i].dari + ' - ' + data[i].sampai + '</td>' +
                        '<td style="text-align: left;">' + data[i].pelaksanaan_kegiatan + '</td>' +
                        '<td style="text-align: left;">' + data[i].surat_dikerjakan + '</td>' +
                        '</tr>';
                }
                $('#show_data').html(html);


            },
            error: function(xhr, ajaxOptions, thrownError) {
                // alert(xhr.status);
                // alert(thrownError);
                console.log("Data Kosong");
            }

        });
    }

    $('#btn_simpan').on('click', function() {
        // var nama = $('input[name="nama"]').val();
        // var periode = $('input[name="periode"]').val();
        var nama = $('#nama').val();
        var periode = $('#periode').val();
        var score = $('#score').val();
        var keterangan = $('#keterangan').val();

        // var pelakKegiatan = $('#pelakKegiatan').val();
        // var jumlahSurat = $('input[name="jumlahSurat"]').val();
        // var tempatKerja = $('#tempatKerja').val();
        // var tindakLanjut = $('#tindakLanjut').val();
        // var empID = $('#empID').val();
        // console.log(nama);
        // console.log(periode);
        // console.log(score);
        // console.log(keterangan);
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('index.php/SVC_Submit/submit_kinerjaPegawai') ?>",
            dataType: "JSON",
            data: {
                nama: nama,
                score: score,
                periode: periode,
                keterangan: keterangan,
            },
            success: function(data) {
                console.log(data);
                if (data.error) {
                    if (data.nama_error != '') {
                        $('#nama_error').html(data.nama_error);
                    } else {
                        $('#nama_error').html('');
                    }
                    if (data.score_error != '') {
                        $('#score_error').html(data.score_error);
                    } else {
                        $('#score_error').html('');
                    }
                    if (data.periode_error != '') {
                        $('#periode_error').html(data.periode_error);
                    } else {
                        $('#periode_error').html('');
                    }
                    if (data.keterangan_error != '') {
                        $('#keterangan_error').html(data.keterangan_error);
                    } else {
                        $('#keterangan_error').html('');
                    }
                }

                if (data.success) {
                    //  $('#success_message').html(data.success);
                    $('#nama').val("");
                    $('#periode').val("");
                    $('#score').val("");
                    $('#summernote').val("");

                    $('#nama').html('');
                    $('#periode').html('');
                    $('#score').html('');
                    $('#summernote').html('');
                    tampil_data_laporan();
                    window.location.href = "<?php echo base_url('index.php/PenilaianKinerja/daftarKinerjaKtu') ?>"
                }
            },
            error: function(data, jqXHR, textStatus, errorThrown) {
                alert('Error adding / update data');
                console.log(textStatus);
                // $('#btn_simpan').text('save'); //change button text
                $('#btn_simpan').attr('disabled', false); //set button enable 

            },
        });
        return false;
    });

    $('#summernote').summernote({
        height: "300px",
        toolbar: [
            // ['style', ['style']],
            ['font', ['bold', 'italic', 'underline']],
            // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
            ['fontname', ['fontname']],
            ['fontsize', ['fontsize']],
            // ['color', ['color']],
            ['para', ['ol', 'ul', 'paragraph', 'height']],
            // ['table', ['table']],
            // ['insert', ['link']],
            // ['view', ['undo', 'redo', 'fullscreen', 'codeview', 'help']]
        ]
    });
</script>
</body>

</html>