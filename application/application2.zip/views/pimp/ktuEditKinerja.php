<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Penilaian PNASN</h1>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Penilaian</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <label>Masukan Penilaian</label>
                            <input type="text" class="form-control" id="" placeholder="">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card card-primary">
                        <form enctype="multipart/form-data" method="post" action="<?php echo base_url() ?>index.php/admin/submit_updateKinerjaPegawai">
                            <div class="card-header">
                                <h3 class="card-title">Form Input Penilaian</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="form-group">
                                    <h2 style="text-align: left;">Penilaian PNASN</h2>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Nama PNASN</label><br>
                                                <input type="text" name="kinid" value="<?php echo $kinId ?>" hidden>
                                                <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('nama'); ?></label>
                                                <select name="nama" class="form-control custom-select" id="nama" disabled>
                                                    <?php
                                                    foreach ($listPegawai as $data) {
                                                        if ($dataPegawai[0]->emp_id == $data->emp_id) {
                                                            echo '<option selected value="' . $data->emp_id . '">' . $data->nama_depan . " " . $data->nama_belakang . '</option>';
                                                        } else {
                                                            echo '<option value="' . $data->emp_id . '">' . $data->nama_depan . " " . $data->nama_belakang . '</option>';
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label>Periode Penilaian</label>
                                                <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('periode'); ?></label>
                                                <select name="periode" class="form-control custom-select" id="periode" disabled>
                                                    <?php
                                                    if (!empty(substr($dataPegawai[0]->periode, 0, -3))) {
                                                        foreach ($dataBulan as $key => $value) {
                                                            if ($key ==  substr($dataPegawai[0]->periode, 0, -3)) {
                                                                echo "<option selected value='" . $key . "'>" . $value . "</option>";
                                                            } else {
                                                                echo "<option value='" . $key . "'>" . $value . "</option>";
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Score Penilaian</label>
                                                <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('score'); ?></label>
                                                <select name="score" class="form-control custom-select" id="score" disabled>
                                                    <?php
                                                    foreach ($dataScore as $data => $value) {
                                                        if ($dataPegawai[0]->penilaian == $data) {
                                                            echo "<option selected value='" . $data . "'>" . $value . "</option>";
                                                        } else {
                                                            echo "<option value='" . $data . "'>" . $value . "</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h2 class="card-title"><b>Ringkasan Penilaian Pimpinan</b></h2>
                                                        <p class="card-text"><?php echo $dataPegawai[0]->keterangan ?></p>
                                                        <!-- <a class="btn btn-primary" href="<?= base_url('post/daftarPost'); ?>">Kembali</a> -->
                                                    </div>
                                                </div>
                                                <!-- <label>Keterangan</label>
                                                <textarea name="keterangan" class="keterangan" id="summernote" style="height: 300px;">
                                                Tuliskan <em>keterangan</em> <u>disini</u>                               
                                                </textarea> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button class="btn btn-danger" onclick="window.history.go(-1); return false;">Kembali</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
    <?php
    $this->load->view('admin/template/4footer');
    ?>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>asset/plugin/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>asset/plugin/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & plugin -->
<script src="<?php echo base_url() ?>asset/plugin/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/jszip/jszip.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src=" <?php echo base_url() ?>asset/js/adminlte.min.js"></script>
<!-- Page specific script -->
<script src="<?php echo base_url() ?>asset/plugin/summernote/summernote-bs4.min.js"></script>
<script>
    function goBack() {
        window.history.back();
    }

    $(function() {
        $("#example1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    });

    var sukses = "<?php echo $this->session->userdata('a202') ?>";
    var gagal = "<?php echo $this->session->userdata('a203') ?>";
    // var is_send = "<?php echo $dataPegawai[0]->is_send ?>";
    // var elem = document.getElementById('btnkirim');

    // if (is_send == 1) {
    //     // elem.style.display = 'none';
    // }

    $(document).ready(function() {

        if (gagal !== "") {
            $("#myModal203").modal();
        }
        if (sukses !== "") {
            $("#myModal202").modal();
        }

        var data = "<?php echo $dataPegawai[0]->keterangan ?>";
        $('#summernote').summernote('code', data);
        // $('#summernote').summernote({
        //     height: 150,
        // });

        $('#summernote').summernote({
            height: "300px",
            callbacks: {
                onImageUpload: function(image) {
                    uploadImage(image[0]);
                },
                onMediaDelete: function(target) {
                    deleteImage(target[0].src);
                }
            }
        });

        function uploadImageSummerNote(image) {
            var data = new FormData();
            data.append("image", image);
            $.ajax({
                url: "<?php echo site_url('post/upload_image') ?>",
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: "POST",
                success: function(url) {
                    $('#summernote').summernote("insertImage", url);
                },
                error: function(data) {
                    console.log(data);
                }
            });
        }

        function deleteImageSummerNote(src) {
            $.ajax({
                data: {
                    src: src
                },
                type: "POST",
                url: "<?php echo site_url('post/delete_image') ?>",
                cache: false,
                success: function(response) {
                    console.log(response);
                }
            });
        }



    });
</script>
</body>

</html>