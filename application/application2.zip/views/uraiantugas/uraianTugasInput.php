 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
     <!-- Modal Sukses -->
     <div id="myModal202" class="modal fade">
         <div class="modal-dialog modal-confirm">
             <div class="modal-content">
                 <div class="modal-header">
                     <div class="icon-box bg-success">
                         <i class="fas fa-check fa-3x"></i>
                     </div>
                 </div>
                 <div class="modal-body">
                     <h2 class="text-center">Messages</h2>
                     <p style="text-align: center;">Input Kegiatan Berhasil</p>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                 </div>
             </div>
         </div>
     </div>



     <!-- Modal Gagal -->
     <div id="myModal203" class="modal fade">
         <div class="modal-dialog modal-confirm">
             <div class="modal-content">
                 <div class="modal-header">
                     <div class="icon-box">
                         <i class="fas fa-times fa-3x"></i>
                     </div>
                 </div>
                 <div class="modal-body">
                     <h2 class="text-center">Messages</h2>
                     <p style="text-align: center;">Input Kegiatan Gagal, Harap Cek Kembali form isian anda !!!</p>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                 </div>
             </div>
         </div>
     </div>

     <div id="ModalErrorFormSave" class="modal fade">
         <div class="modal-dialog modal-confirm">
             <div class="modal-content">
                 <div class="modal-header">
                     <div class="icon-box">
                         <i class="fas fa-times fa-3x"></i>
                     </div>
                 </div>
                 <div class="modal-body">
                     <h2 class="text-center">Messages</h2>
                     <p style="text-align: center;">Simpan Kegiatan Gagal, Harap Cek Waktu kegiatan anda !!!</p>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                 </div>
             </div>
         </div>
     </div>


     <!-- Modal Error -->
     <div id="ModalErrorForm" class="modal fade">
         <div class="modal-dialog modal-confirm">
             <div class="modal-content">
                 <div class="modal-header">
                     <div class="icon-box">
                         <i class="fas fa-times fa-3x"></i>
                     </div>
                 </div>
                 <div class="modal-body">
                     <h2 class="text-center">Messages</h2>
                     <p style="text-align: center;">Input Kegiatan Gagal, Harap Cek Kembali form isian anda !!!</p>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-danger btn-block" data-dismiss="modal">Tutup</button>
                 </div>
             </div>
         </div>
     </div>

     <!-- Modal Hapus -->
     <div id="ModalHapus" class="modal fade">
         <div class="modal-dialog modal-confirm">
             <div class="modal-content">
                 <div class="modal-header">
                     <div class="icon-box bg-warning">
                         <i class="fas fa-question fa-3x"></i>
                         <!-- <i class="fas fa-times "></i> -->
                     </div>
                 </div>
                 <div class="modal-body">
                     <input type="text" name="kode" id="textkode" value="" hidden>
                     <h2 class="text-center">Messages</h2>
                     <p style="text-align: center;">Apakah anda yakin ingin menghapus kegiatan ini dari daftar?</p>
                 </div>
                 <div class="modal-footer">
                     <button class="btn bg-info btn-block" id="btn_hapus">Hapus</button>
                     <button class="btn bg-danger btn-block" data-dismiss="modal">Tutup</button>
                 </div>
             </div>
         </div>
     </div>

     <!-- MODAL ADD -->
     <div class="modal fade" id="ModalaAdd" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header">
                     <label>Form Input</label>
                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                 </div>
                 <form action="#" id="form" class="form-horizontal">
                     <div class="modal-body">
                         <div class="form-group">
                             <label>Pilih Waktu Kegiatan</label>
                             <input name="waktu" id="waktu" type="date" class="form-control" placeholder="">
                             <span id="waktu_error" class="text-danger"></span>
                             <input type="text" name="empID" id="empID" value="<?php echo $this->session->userdata('emp_id') ?>" hidden />
                         </div>

                         <div class="row">
                             <div class="col-md-6 col-sm-6 col-lg-6">
                                 <div class="form-group">
                                     <label>Dari</label>
                                     <input name="dari" id="dari" type="time" class="form-control" placeholder="">
                                     <span id="dari_error" class="text-danger"></span>
                                 </div>
                             </div>
                             <div class="col-md-6 col-sm-6 col-lg-6">
                                 <div class="form-group">
                                     <label>Sampai dengan</label>
                                     <input name="sampai" id="sampai" type="time" class="form-control" placeholder="">
                                     <span id="sampai_error" class="text-danger"></span>
                                 </div>
                             </div>
                         </div>

                         <div class="form-group">
                             <label>Nama Kegiatan</label>
                             <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('nama'); ?></label>
                             <select name="namaKegiatan" class="form-control custom-select" id="namaKegiatan">
                                 <?php
                                    foreach ($dataKegiatan as $data) {
                                        echo '<option value="' . $data->kegiatan_id . '" >' . $data->nama .  '</option>';
                                    }
                                    ?>
                             </select>
                             <span id="namaKegiatan_error" class="text-danger"></span>
                         </div>

                         <div class="form-group">
                             <label>Pelaksanaan Kegiatan</label>
                             <textarea name="pelakKegiatan" class="pelakKegiatan" id="pelakKegiatan" style="width: 100%;  padding: 20px;margin: 15px 0;"></textarea>
                             <span id="pelakKegiatan_error" class="text-danger"></span>
                         </div>

                         <label style="color: red;">Info : <br>
                             * Jika kegiatan berkaitan dengan penyelesaikan dokumen isi banyaknya dokumen yang dikerjakan jika tidak isi dengan "1"</label>

                         <div class="suratDikerjakan">
                             <div class=" form-group">
                                 <label>Jumlah yang telah diselesaikan</label>
                                 <input style="width: 20%;" type="number" name="jumlahSurat" id="jumlahSurat" class="form-control" placeholder="" value="1">
                                 <span id="jumlahSurat_error" class="text-danger"></span>
                             </div>
                         </div>

                         <br>
                         <!-- <div class="form-group" style="text-align: center;">
                             <label>----- Status Kegiatan ------</label>
                         </div>

                         <div class="form-group">
                             <label>Tempat Kerja</label>
                             <select name="tempatKerja" id="tempatKerja" class="custom-select">
                                 <option value="Kantor">Kantor</option>
                                 <option value="Rumah">Rumah</option>
                             </select>
                             <span id="tempatKerja_error" class="text-danger"></span>
                         </div>

                         <div class="form-group">
                             <label>Tindak Lanjut</label>
                             <select name="tindakLanjut" id="tindakLanjut" class="custom-select">
                                 <option value="Sudah dikerjakan">Sudah dikerjakan</option>
                                 <option value="Belum dikerjakan">Belum dikerjakan</option>
                             </select>
                             <span id="tindakLanjut_error" class="text-danger"></span>
                         </div> -->

                     </div>

                     <div class="modal-footer">
                         <button type="button" id="btn_simpan" class="btn btn-primary">Simpan</button>
                         <button class="btn" id="btn_tutup" data-dismiss="modal" aria-hidden="true">Tutup</button>
                         <!-- <button class="btn btn-info" id="btn_simpan">Simpan</button> -->
                     </div>
                 </form>
             </div>
         </div>
     </div>
     <!--END MODAL ADD-->

     <!-- MODAL EDIT -->
     <div class="modal fade" id="ModalaEdit" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header">
                     <label>Form Edit</label>
                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                 </div>
                 <form class="form-horizontal">
                     <div class="modal-body">
                         <input type="text" name="empID_edit" id="empID_edit" value="<?php echo $this->session->userdata('emp_id') ?>" hidden />
                         <input type="text" name="iddetail_edit" id="iddetail_edit" hidden />

                         <div class="form-group">
                             <label>Pilih Waktu Kegiatan</label>
                             <input name="waktu_edit" id="waktu_edit" type="date" class="form-control" placeholder="">
                             <span id="waktuEdit_error" class="text-danger"></span>
                             <!-- <input type="text" name="empID" id="empID" value="<?php echo $this->session->userdata('emp_id') ?>" hidden /> -->
                         </div>

                         <div class="row">
                             <div class="col-md-6 col-sm-6 col-lg-6">
                                 <div class="form-group">
                                     <label>Dari</label>
                                     <input name="dari_edit" id="dari_edit" type="time" class="form-control" placeholder="">
                                     <span id="dariEdit_error" class="text-danger"></span>
                                 </div>
                             </div>
                             <div class="col-md-6 col-sm-6 col-lg-6">
                                 <div class="form-group">
                                     <label>Sampai dengan</label>
                                     <input name="sampai_edit" id="sampai_edit" type="time" class="form-control" placeholder="">
                                     <span id="sampaiEdit_error" class="text-danger"></span>
                                 </div>
                             </div>
                         </div>

                         <div class="form-group">
                             <label>Nama Kegiatan</label>
                             <label style="color: red; float: right; font-size: 10pt;"> <?php echo form_error('nama'); ?></label>
                             <select name="namaKegiatan_edit" class="form-control custom-select" id="namaKegiatan_edit">
                                 <?php
                                    foreach ($dataKegiatan as $data) {
                                        echo '<option value="' . $data->kegiatan_id . '" >' . $data->nama .  '</option>';
                                    }
                                    ?>
                             </select>
                             <span id="namaKegiatanEdit_error" class="text-danger"></span>
                         </div>

                         <div class="form-group">
                             <label>Pelaksanaan Kegiatan</label>
                             <textarea name="pelakKegiatan_edit" class="pelakKegiatan" id="pelakKegiatan_edit" style="width: 100%;  padding: 20px;margin: 15px 0;"></textarea>
                             <span id="pelakKegiatanEdit_error" class="text-danger"></span>
                         </div>

                         <div class="suratDikerjakan">
                             <div class=" form-group">
                                 <label>Surat yang telah dikerjakan</label>
                                 <input type="number" name="jumlahSurat_edit" id="jumlahSurat_edit" class="form-control" placeholder="" value="0">
                                 <span id="jumlahSuratEdit_error" class="text-danger"></span>
                             </div>
                         </div>

                         <br>
                         <!-- <div class="form-group" style="text-align: center;">
                             <label>----- Status Kegiatan ------</label>
                         </div>

                         <div class="form-group">
                             <label>Tempat Kerja</label>
                             <select name="tempatKerja_edit" id="tempatKerja_edit" class="custom-select">
                                 <option value="Kantor">Kantor</option>
                                 <option value="Rumah">Rumah</option>
                             </select>
                             <span id="tempatKerja_error" class="text-danger"></span>
                         </div>

                         <div class="form-group">
                             <label>Tindak Lanjut</label>
                             <select name="tindakLanjut_edit" id="tindakLanjut_edit" class="custom-select">
                                 <option value="Sudah dikerjakan">Sudah dikerjakan</option>
                                 <option value="Belum dikerjakan">Belum dikerjakan</option>
                             </select>
                             <span id="tindakLanjut_error" class="text-danger"></span>
                         </div> -->

                     </div>

                     <div class="modal-footer">
                         <button type="button" id="btn_update" class="btn btn-primary">Simpan</button>
                         <button class="btn" id="btn_tutup" data-dismiss="modal" aria-hidden="true">Tutup</button>
                         <!-- <button class="btn btn-info" id="btn_simpan">Simpan</button> -->
                     </div>
                 </form>
             </div>
         </div>
     </div>


     <!-- Content Header (Page header) -->
     <section class="content-header">
         <div class="container-fluid">
             <div class="row mb-2">
                 <div class="col-sm-6">
                     <h1>Input Uraian Tugas</h1>
                 </div>
                 <div class="col-sm-6">

                 </div>
             </div>
         </div><!-- /.container-fluid -->
     </section>

     <!-- Main content -->
     <section class="content">
         <div class="container-fluid">
             <form>
                 <!-- Card Base -->
                 <div class="card card-primary">
                     <div class="card-header">
                         <h3 class="card-title">Input Uraian Tugas</h3>
                     </div>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12 col-sm-12 col-lg-12">
                                 <div class="card card-default">
                                     <div class="card-header">
                                         <h3 class="card-title">Daftar Kegiatan</h3>
                                     </div>
                                     <div class="card-body">
                                         <div class="pull-right"><a href="#" class="btn btn-sm btn-success" data-toggle="modal" data-target="#ModalaAdd"><span class="fa fa-plus"></span> Tambah Kegiatan</a></div>
                                         <br>
                                         <div class="card-body table-responsive">
                                             <table id="example3" class="table responive table-bordered table-striped">
                                                 <thead>
                                                     <tr style="text-align: center; width: 25%;">
                                                         <th>No.</th>
                                                         <th>Waktu</th>
                                                         <th>Uraian Kegiatan</th>
                                                         <th>Jumlah Terselesaikan</th>
                                                         <th>Aksi</th>
                                                     </tr>
                                                 </thead>
                                                 <tbody id="show_data">

                                                 </tbody>
                                             </table>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div><!-- /.card base -->
             </form>
         </div><!-- /.container-fluid -->
     </section>
     <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->
 <footer class="main-footer">
     <?php
        $this->load->view('admin/template/4footer');
        ?>
 </footer>

 <!-- Control Sidebar -->
 <aside class="control-sidebar control-sidebar-dark">
     <!-- Control sidebar content goes here -->
 </aside>
 <!-- /.control-sidebar -->
 </div>
 <!-- ./wrapper -->

 <!-- jQuery -->
 <script src=" <?php echo base_url() ?>asset/plugin/jquery/jquery.min.js"></script>
 <!-- Bootstrap 4 -->
 <script src=" <?php echo base_url() ?>asset/plugin/bootstrap/js/bootstrap.bundle.min.js"></script>
 <!-- bs-custom-file-input -->
 <script src=" <?php echo base_url() ?>asset/plugin/bs-custom-file-input/bs-custom-file-input.min.js"></script>
 <!-- AdminLTE App -->
 <script src=" <?php echo base_url() ?>asset/js/adminlte.min.js"></script>
 <!-- AdminLTE for demo purposes -->
 <script src=" <?php echo base_url() ?>asset/js/demo.js"></script>
 <!-- Page specific script -->
 <script src="<?php echo base_url() ?>asset/plugin/summernote/summernote-bs4.min.js"></script>
 <!-- DataTables  & plugin -->
 <script src="<?php echo base_url() ?>asset/plugin/datatables/jquery.dataTables.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-responsive/js/dataTables.responsive.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/dataTables.buttons.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/jszip/jszip.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/pdfmake/pdfmake.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/pdfmake/vfs_fonts.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.html5.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.print.min.js"></script>
 <script src="<?php echo base_url() ?>asset/plugin/datatables-buttons/js/buttons.colVis.min.js"></script>
 <script>
     //  Run Method
     tampil_data_kegiatan();

     // All Method
     $(function() {
         bsCustomFileInput.init();
     });

     $(function() {
         $('#summernote').summernote({
             toolbar: [
                 // [groupName, [list of button]]
                 ['style', ['bold', 'italic', 'underline', 'clear']],
                 ['fontsize', ['fontsize']],
                 ['color', ['color']],
                 ['para', ['ul', 'ol', 'paragraph']],
                 ['height', ['height']]
             ],
             height: 150
         });

     })

     function tampil_data_kegiatan() {
         $.ajax({
             type: 'GET',
             url: '<?php echo base_url() ?>index.php/SVC_GetAjax/daftar_kegiatan_pegawai',
             async: false,
             dataType: 'json',
             success: function(data) {
                 var html = '';
                 var i;
                 var x = 1;
                 for (i = 0; i < data.length; i++) {
                     html += '<tr>' +
                         '<td  style="text-align: center;">' + x++ + '</td>' +
                         '<td style="text-align: center;">' + data[i].waktu + '</td>' +
                         '<td style=" text-align: justify; text-justify: inter-word;">' + data[i].pelaksanaan_kegiatan + '</td>' +
                         '<td style="text-align: center; width: 10%">' + data[i].surat_dikerjakan + '</td>' +
                         '<td style="text-align:right;">' +
                         '<a href="javascript:;" class="btn btn-info btn-xs item_edit" style="text-align: center; width: 100%" data="' + data[i].lap_detail_id + '">Edit</a>' + ' ' +
                         '</td>' +
                         '</tr>';
                 }
                 $('#show_data').html(html);
             }

         });
     }

     $("#example3").DataTable({
         "responsive": true,
         "lengthChange": false,
         "autoWidth": false,
         "buttons": ["copy", "csv", "excel", "pdf", "print"]
     }).buttons().container().appendTo('#example3_wrapper .col-md-6:eq(0)');

     //  Tutup Modal
     $('#btn_tutup').on('click', function() {
         $('#waktu').val("");
         $('#dari').val("");
         $('#sampai').val("");
         $('#namaKegiatan').val("");
         $('#pelakKegiatan').val("");
         $('#jumlahSurat').val("");
         $('#tempatKerja').val("");
         $('#tindakLanjut').val("");

         $('#waktu_error').html('');
         $('#dari_error').html('');
         $('#sampai_error').html('');
         $('#namaKegiatan_error').html('');
         $('#pelakKegiatan_error').html('');
         $('#jumlahSurat_error').html('');
         $('#tempatKerja_error').html('');
         $('#tindakLanjut_error').html('');
     });

     //Simpan Data
     $('#btn_simpan').on('click', function() {
         var waktu = $('input[name="waktu"]').val();
         var dari = $('input[name="dari"]').val();
         var sampai = $('input[name="sampai"]').val();
         var namaKegiatan = $('#namaKegiatan').val();
         var pelakKegiatan = $('#pelakKegiatan').val();
         var jumlahSurat = $('input[name="jumlahSurat"]').val();
         var tempatKerja = $('#tempatKerja').val();
         var tindakLanjut = $('#tindakLanjut').val();
         var empID = $('#empID').val();
         //  console.log(waktu);
         $.ajax({
             type: "POST",
             url: "<?php echo base_url('index.php/SVC_Submit/submit_uraianTugas') ?>",
             dataType: "JSON",
             data: {
                 empID: empID,
                 waktu: waktu,
                 dari: dari,
                 sampai: sampai,
                 namaKegiatan: namaKegiatan,
                 pelakKegiatan: pelakKegiatan,
                 jumlahSurat: jumlahSurat,
                 //  tempatKerja: tempatKerja,
                 //  tindakLanjut: tindakLanjut
             },
             success: function(data) {
                 console.log(data);
                 if (data.error) {
                     if (data.waktu_error != '') {
                         $('#waktu_error').html(data.waktu_error);
                     } else {
                         $('#waktu_error').html('');
                     }
                     if (data.dari_error != '') {
                         $('#dari_error').html(data.dari_error);
                     } else {
                         $('#dari_error').html('');
                     }
                     if (data.sampai_error != '') {
                         $('#sampai_error').html(data.sampai_error);
                     } else {
                         $('#sampai_error').html('');
                     }
                     if (data.namaKegiatan_error != '') {
                         $('#namaKegiatan_error').html(data.namaKegiatan_error);
                     } else {
                         $('#namaKegiatan_error').html('');
                     }
                     if (data.pelakKegiatan_error != '') {
                         $('#pelakKegiatan_error').html(data.pelakKegiatan_error);
                     } else {
                         $('#pelakKegiatan_error').html('');
                     }
                     if (data.jumlahSurat_error != '') {
                         $('#jumlahSurat_error').html(data.jumlahSurat_error);
                     } else {
                         $('#jumlahSurat_error').html('');
                     }
                     if (data.tempatKerja_error != '') {
                         $('#tempatKerja_error').html(data.tempatKerja_error);
                     } else {
                         $('#tempatKerja_error').html('');
                     }
                     if (data.tindakLanjut_error != '') {
                         $('#tindakLanjut_error').html(data.tindakLanjut_error);
                     } else {
                         $('#tindakLanjut_error').html('');
                     }
                 }

                 if (data.success) {
                     //  $('#success_message').html(data.success);
                     $('#waktu').val("");
                     $('#dari').val("");
                     $('#sampai').val("");
                     $('#namaKegiatan').val("");
                     $('#pelakKegiatan').val("");
                     $('#jumlahSurat').val("");
                     $('#tempatKerja').val("");
                     $('#tindakLanjut').val("");

                     $('#waktu_error').html('');
                     $('#dari_error').html('');
                     $('#sampai_error').html('');
                     $('#namaKegiatan_error').html('');
                     $('#pelakKegiatan_error').html('');
                     $('#jumlahSurat_error').html('');
                     $('#tempatKerja_error').html('');
                     $('#tindakLanjut_error').html('');

                     tampil_data_kegiatan();
                     window.location.href = "<?php echo base_url('index.php/UraianTugas/uraianTugasInput') ?>"
                     $('#ModalaAdd').modal('hide');
                     //  tampil_data_kegiatan();
                 }
             },
             error: function(data, jqXHR, textStatus, errorThrown) {
                 alert('Error adding / update data');
                 console.log(textStatus);
                 $('#btn_simpan').text('save'); //change button text
                 $('#btn_simpan').attr('disabled', false); //set button enable 

             },
         });
         return false;
     });


     //GET UPDATE
     $('#show_data').on('click', '.item_edit', function() {
         var id = $(this).attr('data');
         $.ajax({
             type: "GET",
             url: "<?php echo base_url('index.php/SVC_Submit/pegawai_updateKegiatan') ?>",
             dataType: "JSON",
             data: {
                 id: id
             },
             success: function(data) {
                 var i;
                 for (i = 0; i < data.length; i++) {
                     $('#ModalaEdit').modal('show');
                     $('#waktu_edit').val(data[i].waktu);
                     $('#iddetail_edit').val(data[i].lap_detail_id);
                     $('#waktu_edit').val(data[i].waktu);
                     $('#dari_edit').val(data[i].dari);
                     $('#sampai_edit').val(data[i].sampai);
                     $('#namaKegiatan_edit').val(data[i].kegiatan_id);
                     $('#pelakKegiatan_edit').val(data[i].pelaksanaan_kegiatan);
                     $('#jumlahSurat_edit').val(data[i].surat_dikerjakan);
                     //  $('#tempatKerja_edit').val(data[i].lokasi_kerja);
                     //  $('#tindakLanjut_edit').val(data[i].tindak_lanjut);
                 }
             }
         });
         return false;
     });

     //Update Kegiatan
     $('#btn_update').on('click', function() {
         var iddetail_edit = $('input[name="iddetail_edit"]').val();
         var dari_edit = $('input[name="dari_edit"]').val();
         var sampai_edit = $('input[name="sampai_edit"]').val();
         var namaKegiatan_edit = $('#namaKegiatan_edit').val();
         var pelakKegiatan_edit = $('#pelakKegiatan_edit').val();
         var jumlahSurat_edit = $('input[name="jumlahSurat_edit"]').val();
         var waktu = $('input[name="waktu_edit"]').val();
         //  var tempatKerja_edit = $('#tempatKerja_edit').val();
         //  var tindakLanjut_edit = $('#tindakLanjut_edit').val();
         var empID_edit = $('#empID_edit').val();

         $.ajax({
             type: "POST",
             url: "<?php echo base_url('index.php/SVC_Submit/submit_updateUraianTugas') ?>",
             dataType: "JSON",
             data: {
                 iddetail: iddetail_edit,
                 dari: dari_edit,
                 sampai: sampai_edit,
                 namaKegiatan: namaKegiatan_edit,
                 pelakKegiatan: pelakKegiatan_edit,
                 jumlahSurat: jumlahSurat_edit,
                 waktu: waktu,
                 //  tempatKerja: tempatKerja_edit,
                 //  tindakLanjut: tindakLanjut_edit,
                 empID: empID_edit,
             },
             success: function(data) {
                 //  console.log(data);
                 if (data.error) {
                     if (data.waktuEdit_error != '') {
                         $('#waktuEdit_error').html(data.dari_error);
                     } else {
                         $('#waktuEdit_error').html('');
                     }
                     if (data.dari_error != '') {
                         $('#dariEdit_error').html(data.dari_error);
                     } else {
                         $('#dariEdit_error').html('');
                     }
                     if (data.sampai_error != '') {
                         $('#sampaiEdit_error').html(data.sampai_error);
                     } else {
                         $('#sampaiEdit_error').html('');
                     }
                     if (data.namaKegiatan_error != '') {
                         $('#namaKegiatanEdit_error').html(data.namaKegiatan_error);
                     } else {
                         $('#namaKegiatanEdit_error').html('');
                     }
                     if (data.pelakKegiatan_error != '') {
                         $('#pelakKegiatanEdit_error').html(data.pelakKegiatan_error);
                     } else {
                         $('#pelakKegiatanEdit_error').html('');
                     }
                     if (data.jumlahSurat_error != '') {
                         $('#jumlahSuratEdit_error').html(data.jumlahSurat_error);
                     } else {
                         $('#jumlahSuratEdit_error').html('');
                     }
                     if (data.tempatKerja_error != '') {
                         $('#tempatKerjaEdit_error').html(data.tempatKerja_error);
                     } else {
                         $('#tempatKerjaEdit_error').html('');
                     }
                     if (data.tindakLanjut_error != '') {
                         $('#tindakLanjutEdit_error').html(data.tindakLanjut_error);
                     } else {
                         $('#tindakLanjutEdit_error').html('');
                     }
                 }

                 if (data.success) {
                     console.log(data);
                     //  $('#success_message').html(data.success);
                     $('#waktu').val("");
                     $('#dari').val("");
                     $('#sampai').val("");
                     $('#namaKegiatan').val("");
                     $('#pelakKegiatan').val("");
                     $('#jumlahSurat').val("");
                     $('#tempatKerja').val("");
                     $('#tindakLanjut').val("");

                     $('#waktu_error').html('');
                     $('#dari_error').html('');
                     $('#sampai_error').html('');
                     $('#namaKegiatan_error').html('');
                     $('#pelakKegiatan_error').html('');
                     $('#jumlahSurat_error').html('');
                     $('#tempatKerja_error').html('');
                     $('#tindakLanjut_error').html('');

                     //  $('#jenis').val("");
                     $('#ModalaEdit').modal('hide');
                     tampil_data_kegiatan();
                 }

             },
             //  success: function(data) {
             //      //  $('[name="waktu_edit"]').val("");
             //      //  $('[name="dari_edit"]').val("");
             //      //  $('[name="sampai_edit"]').val("");
             //      $('#waktu').val("");
             //      $('#dari').val("");
             //      $('#sampai').val("");
             //      $('#namaKegiatan').val("");
             //      $('#pelakKegiatan').val("");
             //      $('#jumlahSurat').val("");
             //      $('#tempatKerja').val("");
             //      $('#tindakLanjut').val("");
             //      $('#ModalaEdit').modal('hide');
             //      tampil_data_barang();
             //  },
             error: function(jqXHR, textStatus, errorThrown) {
                 alert('Error adding / update data');
                 //  console.log(data);
                 //  $('#btn_simpan').text('save'); //change button text
                 //  $('#btn_simpan').attr('disabled', false); //set button enable 

             },
         });
         return false;
     });
 </script>

 </body>

 </html>