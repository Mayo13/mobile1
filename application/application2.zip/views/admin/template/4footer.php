<div class="float-right d-none d-sm-block" style="font-size: 12pt;">
    <b>Version</b> 1.0
</div>
<strong style="font-size: 12pt;">Copyright &copy; 2020 HRMS PNASN IMIGRASI <br></strong>